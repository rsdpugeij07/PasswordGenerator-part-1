# Password Generator — Autumn 2026 Edition

A Java console application with:

- Secure password generation using `SecureRandom`
- Password strength checking
- Contact form
- Bug reporting
- Gmail SMTP sending
- Autumn 2026 logo and countdown
- Windows build/run scripts
- Linux/macOS build/run scripts

## Requirements

- Java 21 or newer
- Maven 3.8 or newer
- A Gmail account with an App Password for SMTP

## Configure email

Set these environment variables before running:

- `GMAIL_EMAIL`
- `GMAIL_APP_PASSWORD`
- `RECEIVER_EMAIL`

An example is included in `.env.example`.

## Windows

Build:

    build.bat

Run:

    run.bat

## Linux / macOS

Make scripts executable:

    chmod +x build.sh run.sh

Build:

    ./build.sh

Run:

    ./run.sh

## Manual Maven commands

Build:

    mvn clean package

Run:

    mvn compile exec:java

## Security

Never put a real Gmail password or App Password into the Java source code.
Use environment variables.
