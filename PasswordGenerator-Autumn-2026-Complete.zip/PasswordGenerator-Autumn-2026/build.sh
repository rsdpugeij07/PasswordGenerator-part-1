#!/usr/bin/env bash
set -e
echo "========================================"
echo "Building Password Generator Autumn 2026"
echo "========================================"
mvn clean package
echo
echo "Build successful."
