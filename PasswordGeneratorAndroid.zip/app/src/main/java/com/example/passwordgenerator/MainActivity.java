package com.example.passwordgenerator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends android.app.Activity {
    private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String NUMBERS = "0123456789";
    private static final String SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/";
    private static final String AUTUMN_START = "2026-09-23T00:05:00Z";

    private final SecureRandom random = new SecureRandom();
    private final Handler handler = new Handler();
    private TextView countdown;
    private EditText passwordOutput;
    private SeekBar lengthBar;
    private TextView lengthText;
    private CheckBox uppercase, lowercase, numbers, symbols;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showMain();
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setPadding(dp(8), dp(6), dp(8), dp(6));
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private void showMain() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView title = text("🍂 AUTUMN 2026\n🔐 PASSWORD GENERATOR", 24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        countdown = text("", 15);
        countdown.setGravity(Gravity.CENTER);
        root.addView(countdown, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout scrollContent = new LinearLayout(this);
        scrollContent.setOrientation(LinearLayout.VERTICAL);

        Button generate = button("🔐 Generate Password");
        Button strength = button("🛡 Check Password Strength");
        Button contact = button("📧 Contact Us");
        Button bug = button("🐛 Report a Bug");

        scrollContent.addView(generate);
        scrollContent.addView(strength);
        scrollContent.addView(contact);
        scrollContent.addView(bug);

        root.addView(scrollContent, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("🍁 Autumn 2026 Edition", 13);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        generate.setOnClickListener(v -> showGenerator());
        strength.setOnClickListener(v -> showStrength());
        contact.setOnClickListener(v -> openEmail("CONTACT"));
        bug.setOnClickListener(v -> openEmail("BUG REPORT"));

        updateCountdown();
    }

    private void updateCountdown() {
        if (countdown == null) return;
        try {
            Instant start = Instant.parse(AUTUMN_START);
            Instant now = Instant.now();
            if (now.isBefore(start)) {
                long sec = Duration.between(now, start).getSeconds();
                long days = sec / 86400;
                long hours = (sec % 86400) / 3600;
                long min = (sec % 3600) / 60;
                long seconds = sec % 60;
                countdown.setText(String.format(
                    "🍁 AUTUMN COUNTDOWN • LIVE\n%02d DAYS : %02d HOURS : %02d MIN : %02d SEC",
                    days, hours, min, seconds));
            } else {
                countdown.setText("🍂 AUTUMN 2026 IS NOW AVAILABLE! 🍂");
            }
        } catch (Exception e) {
            countdown.setText("🍂 Autumn 2026");
        }
        handler.postDelayed(this::updateCountdown, 1000);
    }

    private void showGenerator() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView heading = text("🔐 PASSWORD GENERATOR", 23);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        lengthText = text("Password length: 16", 17);
        root.addView(lengthText);

        lengthBar = new SeekBar(this);
        lengthBar.setMax(124);
        lengthBar.setProgress(12);
        root.addView(lengthBar);
        lengthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                lengthText.setText("Password length: " + (p + 4));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        uppercase = new CheckBox(this); uppercase.setText("Uppercase letters"); uppercase.setChecked(true);
        lowercase = new CheckBox(this); lowercase.setText("Lowercase letters"); lowercase.setChecked(true);
        numbers = new CheckBox(this); numbers.setText("Numbers"); numbers.setChecked(true);
        symbols = new CheckBox(this); symbols.setText("Symbols"); symbols.setChecked(true);
        root.addView(uppercase); root.addView(lowercase); root.addView(numbers); root.addView(symbols);

        Button generate = button("Generate");
        root.addView(generate);

        passwordOutput = new EditText(this);
        passwordOutput.setHint("Generated password");
        passwordOutput.setTextSize(18);
        passwordOutput.setInputType(InputType.TYPE_CLASS_TEXT);
        root.addView(passwordOutput);

        Button copy = button("Copy");
        Button back = button("← Back");
        root.addView(copy); root.addView(back);

        setContentView(root);

        generate.setOnClickListener(v -> {
            if (!uppercase.isChecked() && !lowercase.isChecked() &&
                !numbers.isChecked() && !symbols.isChecked()) {
                Toast.makeText(this, "Select at least one character type.", Toast.LENGTH_SHORT).show();
                return;
            }
            String p = generatePassword(lengthBar.getProgress() + 4,
                uppercase.isChecked(), lowercase.isChecked(),
                numbers.isChecked(), symbols.isChecked());
            passwordOutput.setText(p);
        });

        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm =
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Password", passwordOutput.getText()));
            Toast.makeText(this, "Password copied.", Toast.LENGTH_SHORT).show();
        });

        back.setOnClickListener(v -> showMain());
    }

    private String generatePassword(int length, boolean up, boolean low, boolean num, boolean sym) {
        StringBuilder available = new StringBuilder();
        List<Character> chars = new ArrayList<>();
        if (up) { available.append(UPPERCASE); chars.add(randomChar(UPPERCASE)); }
        if (low) { available.append(LOWERCASE); chars.add(randomChar(LOWERCASE)); }
        if (num) { available.append(NUMBERS); chars.add(randomChar(NUMBERS)); }
        if (sym) { available.append(SYMBOLS); chars.add(randomChar(SYMBOLS)); }
        while (chars.size() < length) chars.add(randomChar(available.toString()));
        Collections.shuffle(chars, random);
        StringBuilder out = new StringBuilder();
        for (char c : chars) out.append(c);
        return out.toString();
    }

    private char randomChar(String chars) {
        return chars.charAt(random.nextInt(chars.length()));
    }

    private void showStrength() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView heading = text("🛡 PASSWORD STRENGTH CHECKER", 22);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        EditText input = new EditText(this);
        input.setHint("Enter password");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(input);

        Button check = button("Check Strength");
        root.addView(check);
        TextView result = text("", 18);
        root.addView(result);

        Button back = button("← Back");
        root.addView(back);
        setContentView(root);

        check.setOnClickListener(v -> {
            String p = input.getText().toString();
            if (p.isEmpty()) result.setText("Password cannot be empty.");
            else result.setText("Length: " + p.length() + "\nStrength: " + checkPasswordStrength(p));
        });
        back.setOnClickListener(v -> showMain());
    }

    private String checkPasswordStrength(String p) {
        int score = 0;
        if (p.length() >= 8) score++;
        if (p.length() >= 12) score++;
        if (p.matches(".*[A-Z].*")) score++;
        if (p.matches(".*[a-z].*")) score++;
        if (p.matches(".*[0-9].*")) score++;
        if (p.matches(".*[!@#$%^&*()\\-_=+\\[\\]{};:,.?/].*")) score++;
        if (score <= 2) return "🔴 WEAK";
        if (score <= 4) return "🟡 MEDIUM";
        return "🟢 STRONG";
    }

    private void openEmail(String type) {
        Intent i = new Intent(Intent.ACTION_SENDTO);
        i.setData(Uri.parse("mailto:"));
        i.putExtra(Intent.EXTRA_SUBJECT, "[" + type + "] Password Generator");
        i.putExtra(Intent.EXTRA_TEXT,
            "Password Generator\nAutumn 2026 Edition\n\nMessage:\n");
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No email app is available.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
