import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

public class PasswordGenerator {
    private static final String VERSION = "Autumn 2026 Edition";
    private static final String AUTUMN_START = "2026-09-23T00:05:00Z";

    private static final String SMTP_EMAIL = System.getenv("GMAIL_EMAIL");
    private static final String SMTP_PASSWORD = System.getenv("GMAIL_APP_PASSWORD");
    private static final String RECEIVER_EMAIL = System.getenv("RECEIVER_EMAIL");

    private static final String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    private static final String NUMBERS = "0123456789";
    private static final String SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/";

    private static final Scanner scanner = new Scanner(System.in);
    private static final SecureRandom random = new SecureRandom();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printHeader();
            printMenu();
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> passwordGeneratorMenu();
                case "2" -> passwordStrengthMenu();
                case "3" -> contactForm();
                case "4" -> bugReport();
                case "5" -> {
                    running = false;
                    System.out.println("\nThank you for using Password Generator!");
                    System.out.println("Happy Autumn 2026!");
                }
                default -> {
                    System.out.println("\nInvalid option.");
                    pause();
                }
            }
        }
        scanner.close();
    }

    private static void printHeader() {
        System.out.println("\n==============================================================");
        System.out.println("          ██████╗  ██████╗ ███████╗███████╗");
        System.out.println("          ██╔══██╗██╔════╝ ██╔════╝██╔════╝");
        System.out.println("          ██████╔╝██║  ███╗█████╗  ███████╗");
        System.out.println("          ██╔═══╝ ██║   ██║██╔══╝  ╚════██║");
        System.out.println("          ██║     ╚██████╔╝███████╗███████║");
        System.out.println("          ╚═╝      ╚═════╝ ╚══════╝╚══════╝");
        System.out.println("\n              PASSWORD GENERATOR");
        System.out.println("              Autumn 2026 Edition");
        System.out.println("==============================================================");
        System.out.println("              AUTUMN IS AVAILABLE");
        System.out.println("         SECURE • FAST • MODERN");
        System.out.println();
        showAutumnCountdown();
        System.out.println("==============================================================\n");
    }

    private static void showAutumnCountdown() {
        Instant autumnStart = Instant.parse(AUTUMN_START);
        Instant now = Instant.now();

        if (now.isBefore(autumnStart)) {
            Duration duration = Duration.between(now, autumnStart);
            long totalSeconds = duration.getSeconds();
            long days = totalSeconds / 86400;
            long hours = (totalSeconds % 86400) / 3600;
            long minutes = (totalSeconds % 3600) / 60;
            long seconds = totalSeconds % 60;

            System.out.println("           AUTUMN COUNTDOWN • LIVE");
            System.out.printf("     %02d DAYS : %02d HOURS : %02d MIN : %02d SEC%n",
                    days, hours, minutes, seconds);
        } else {
            System.out.println("          AUTUMN 2026 IS NOW AVAILABLE!");
        }
    }

    private static void printMenu() {
        System.out.println("1. Generate Password");
        System.out.println("2. Check Password Strength");
        System.out.println("3. Contact Us");
        System.out.println("4. Report a Bug");
        System.out.println("5. Exit\n");
    }

    private static void passwordGeneratorMenu() {
        System.out.println("\n---------- PASSWORD GENERATOR ----------");
        int length = getPasswordLength();
        boolean uppercase = getYesNo("Include uppercase letters?");
        boolean lowercase = getYesNo("Include lowercase letters?");
        boolean numbers = getYesNo("Include numbers?");
        boolean symbols = getYesNo("Include symbols?");

        if (!uppercase && !lowercase && !numbers && !symbols) {
            System.out.println("Error: Select at least one character type.");
            pause();
            return;
        }

        String password = generatePassword(length, uppercase, lowercase, numbers, symbols);
        System.out.println("\n==============================================");
        System.out.println("GENERATED PASSWORD");
        System.out.println("==============================================");
        System.out.println(password);
        System.out.println("\nStrength: " + checkPasswordStrength(password));
        System.out.println("Password Length: " + password.length());
        System.out.println("Keep your password private and secure.");
        pause();
    }

    private static int getPasswordLength() {
        while (true) {
            try {
                System.out.print("Password length (4 - 128): ");
                int length = Integer.parseInt(scanner.nextLine().trim());
                if (length >= 4 && length <= 128) return length;
                System.out.println("Please enter a number from 4 to 128.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid number.");
            }
        }
    }

    private static boolean getYesNo(String question) {
        while (true) {
            System.out.print(question + " (Y/N): ");
            String answer = scanner.nextLine().trim().toUpperCase();
            if (answer.equals("Y") || answer.equals("YES")) return true;
            if (answer.equals("N") || answer.equals("NO")) return false;
            System.out.println("Please enter Y or N.");
        }
    }

    private static String generatePassword(int length, boolean uppercase, boolean lowercase,
                                           boolean numbers, boolean symbols) {
        StringBuilder available = new StringBuilder();
        List<Character> result = new ArrayList<>();

        if (uppercase) { available.append(UPPERCASE); result.add(getRandomCharacter(UPPERCASE)); }
        if (lowercase) { available.append(LOWERCASE); result.add(getRandomCharacter(LOWERCASE)); }
        if (numbers)   { available.append(NUMBERS); result.add(getRandomCharacter(NUMBERS)); }
        if (symbols)   { available.append(SYMBOLS); result.add(getRandomCharacter(SYMBOLS)); }

        if (length < result.size()) {
            System.out.println("Note: Length was increased to fit all selected character types.");
        }

        int targetLength = Math.max(length, result.size());
        while (result.size() < targetLength) {
            result.add(getRandomCharacter(available.toString()));
        }

        Collections.shuffle(result, random);
        StringBuilder password = new StringBuilder();
        for (char c : result) password.append(c);
        return password.toString();
    }

    private static char getRandomCharacter(String characters) {
        return characters.charAt(random.nextInt(characters.length()));
    }

    private static void passwordStrengthMenu() {
        System.out.println("\n---------- PASSWORD STRENGTH CHECKER ----------");
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (password.isEmpty()) {
            System.out.println("Password cannot be empty.");
            pause();
            return;
        }

        System.out.println("\nPassword Length: " + password.length());
        System.out.println("Strength: " + checkPasswordStrength(password));
        pause();
    }

    private static String checkPasswordStrength(String password) {
        int score = 0;
        if (password.length() >= 8) score++;
        if (password.length() >= 12) score++;
        if (password.matches(".*[A-Z].*")) score++;
        if (password.matches(".*[a-z].*")) score++;
        if (password.matches(".*[0-9].*")) score++;
        if (password.matches(".*[!@#$%^&*()\\-_=+\\[\\]{};:,.?/].*")) score++;

        if (score <= 2) return "WEAK";
        if (score <= 4) return "MEDIUM";
        return "STRONG";
    }

    private static void contactForm() {
        System.out.println("\n---------- CONTACT US ----------");
        System.out.print("Your Email: ");
        String email = scanner.nextLine().trim();

        if (!isValidEmail(email)) {
            System.out.println("Invalid email address.");
            pause();
            return;
        }

        System.out.print("Subject: ");
        String subject = scanner.nextLine().trim();
        System.out.print("Message: ");
        String message = scanner.nextLine().trim();

        if (subject.isEmpty() || message.isEmpty()) {
            System.out.println("Subject and message cannot be empty.");
            pause();
            return;
        }

        System.out.println("\nSending your message...");
        boolean sent = sendEmail(email, subject, message, "CONTACT");
        System.out.println(sent ? "Contact message sent successfully!" : "Failed to send the message.");
        pause();
    }

    private static void bugReport() {
        System.out.println("\n---------- REPORT A BUG ----------");
        System.out.print("Your Email: ");
        String email = scanner.nextLine().trim();

        if (!isValidEmail(email)) {
            System.out.println("Invalid email address.");
            pause();
            return;
        }

        System.out.print("Bug Subject: ");
        String subject = scanner.nextLine().trim();
        System.out.print("Bug Description: ");
        String message = scanner.nextLine().trim();

        if (subject.isEmpty() || message.isEmpty()) {
            System.out.println("Subject and bug description cannot be empty.");
            pause();
            return;
        }

        System.out.println("\nSending bug report...");
        boolean sent = sendEmail(email, subject, message, "BUG REPORT");
        System.out.println(sent ? "Bug report sent successfully!" : "Failed to send the bug report.");
        pause();
    }

    private static boolean sendEmail(String userEmail, String subject,
                                     String userMessage, String messageType) {
        if (isEmpty(SMTP_EMAIL) || isEmpty(SMTP_PASSWORD) || isEmpty(RECEIVER_EMAIL)) {
            System.out.println("SMTP configuration is missing.");
            System.out.println("Set GMAIL_EMAIL, GMAIL_APP_PASSWORD, and RECEIVER_EMAIL.");
            return false;
        }

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_EMAIL, SMTP_PASSWORD);
            }
        });

        try {
            Message email = new MimeMessage(session);
            email.setFrom(new InternetAddress(SMTP_EMAIL));
            email.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(RECEIVER_EMAIL));
            email.setReplyTo(InternetAddress.parse(userEmail));
            email.setSubject("[" + messageType + "] " + subject);

            String content =
                    "PASSWORD GENERATOR MESSAGE\n" +
                    "AUTUMN 2026 EDITION\n\n" +
                    "Message Type: " + messageType + "\n" +
                    "User Email: " + userEmail + "\n" +
                    "Subject: " + subject + "\n\n" +
                    "Message:\n" +
                    userMessage + "\n\n" +
                    "Application Version: " + VERSION;

            email.setText(content);
            Transport.send(email);
            return true;
        } catch (MessagingException e) {
            System.out.println("SMTP Error: " + e.getMessage());
            return false;
        }
    }

    private static boolean isValidEmail(String email) {
        return email != null && !email.isEmpty()
                && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    private static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static void pause() {
        System.out.println("\nPress Enter to continue...");
        scanner.nextLine();
    }
}
