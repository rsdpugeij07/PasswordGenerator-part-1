# Password Generator — Android APK Project

Android Studio project based on the supplied Autumn 2026 Java Password Generator.

## Features
- Autumn 2026 live countdown
- Secure password generation with `SecureRandom`
- 4–128 character passwords
- Uppercase, lowercase, numbers and symbols
- Password strength checker
- Copy generated password
- Contact Us and Bug Report via the device email app

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build APK(s)**.
4. Install the generated debug APK on an Android device.

## Security
The original desktop program used Gmail SMTP environment variables. The Android version deliberately does not embed Gmail credentials in the APK. Contact and bug-report actions open the user's email application instead.
