Password Generator Android Project

Open this folder in Android Studio.

Requirements:
- Android Studio
- JDK supported by your Android Studio installation
- Internet connection for the first Gradle dependency download

To build:
1. Open the project folder in Android Studio.
2. Allow Gradle Sync to finish.
3. Select Build > Build APK(s).
4. The debug APK will be generated in:
   app/build/outputs/apk/debug/app-debug.apk

For a release APK:
Build > Generate Signed Bundle / APK
