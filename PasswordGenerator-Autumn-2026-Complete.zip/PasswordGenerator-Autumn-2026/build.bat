@echo off
setlocal
echo ========================================
echo Building Password Generator Autumn 2026
echo ========================================
call mvn clean package
if errorlevel 1 (
    echo.
    echo Build failed.
    pause
    exit /b 1
)
echo.
echo Build successful.
pause
