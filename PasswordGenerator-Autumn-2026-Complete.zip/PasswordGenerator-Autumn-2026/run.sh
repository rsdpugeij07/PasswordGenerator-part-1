#!/usr/bin/env bash
set -e
echo "========================================"
echo "Starting Password Generator Autumn 2026"
echo "========================================"
mvn compile exec:java
