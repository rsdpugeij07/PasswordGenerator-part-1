@echo off
setlocal
echo ========================================
echo Starting Password Generator Autumn 2026
echo ========================================
call mvn compile exec:java
pause
